namespace WaiterApp.Pages;

public partial class ChatPage : ContentPage
{
    public ChatPage()
    {
        // Ensure the partial class is generated for XAML
        InitializeComponent();
    }
}
